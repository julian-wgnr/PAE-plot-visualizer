# Example to Get You Started!

## Visualizing Calmodulin with the PAE Plot Visualizer

In this example, we’ll use the Jupyter notebook to visualize the PAE plots of the predicted structure of **Calmodulin**, a key protein in the calcium signal transduction pathway.

---

### Step 1: Input the sequence into AlphaFold 3

Copy and paste the following **Calmodulin-1** amino acid sequence into the [AlphaFold 3 server](https://alphafold.com/):
**MADQLTEEQIAEFKEAFSLFDKDGDGTITTKELGTVMRSLGQNPTEAELQDMINEVDADGNGTIDFPEFLTMMARKMKDTDSEEEIREAFRVFDKDGNGYISAAELRHVMTNLGEKLTDEEVDEMIREADIDGDGQVNYEEFVQMMTAK**

---

### Step 2: Submit your job

- Set the **query name** to: `Calmodulin`
- Start the prediction and wait for the results.

---

### Step 3: Download the results

Once the prediction is complete, download the result file (containing the PAE data) to your local machine.

---

### Step 4: Visualize the plots using the notebook and customize the plot as described below

Open the `PAE_plot_visualizer.ipynb` and:
- Insert the path to your results folder into the script.
- Set the **plot size** to `12 x 12` (width × height)
- Use **font size** `18` for all labels
- Use the **colormap** `inferno`

---

### Step 5: Compare with the results

Compare your output plots to the ones provided in the `examples/` folder. Do they look similar?

---

### Step 6: Reflect and answer

Try to answer the following:

- How many distinct, structured (folded) domains can you identify?
- What does the PAE plot tell you about the flexibility between the two domains?

---

### Solutions

- There are two distinct, folded domains at the N- and C-terminus of the protein. They appear as squares with a low expected position error in the PAE plot. These are the domains that bind a total of four calcium ions.
- The short linker between the domains introduces some flexibility. In the PAE plot, the squares are connected by a short diagonal line separating the two squares.

N.B. Even without adding the calcium ions, AlphaFold actually predicts the calcium-bound state where the linker forms an alpha-helix and is not disordered anymore.

